package com.zybooks.weighttracking_tylerprimas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

public class SMS extends AppCompatActivity {

    private Switch smsSwitch;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        smsSwitch = findViewById(R.id.switch1);
        backButton = findViewById(R.id.button);

        // Set an OnCheckedChangeListener for the switch
        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // User has enabled SMS, perform necessary actions
                Toast.makeText(SMS.this, "SMS Enabled", Toast.LENGTH_SHORT).show();
            } else {
                // User has disabled SMS, perform necessary actions
                Toast.makeText(SMS.this, "SMS Disabled", Toast.LENGTH_SHORT).show();
            }
        });

        // Set an OnClickListener for the back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the previous activity
                finish();
            }
        });
    }
}