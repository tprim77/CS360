package com.zybooks.weighttracking_tylerprimas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class WeightTracking extends AppCompatActivity {

    private TableLayout mTableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);
        mTableLayout = findViewById(R.id.tableLayout);


        FloatingActionButton fab = findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WeightTracking.this, AddWeight.class);
                startActivity(intent);
            }
        });

        Button smsButton = findViewById(R.id.SMSbutton);

        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent smsIntent = new Intent(WeightTracking.this, SMS.class);
                startActivity(smsIntent);
            }
        });


    }
    private void displayDatabaseInfo() {
        // Get a reference to the TableLayout and clear any existing rows
        TableLayout tableLayout = findViewById(R.id.tableLayout);
        tableLayout.removeAllViews();

        // Add the header row
        TableRow headerRow = new TableRow(this);
        TextView weightHeader = new TextView(this);
        weightHeader.setText("Weight");
        weightHeader.setPadding(5, 5, 5, 5);
        headerRow.addView(weightHeader);
        TextView dateHeader = new TextView(this);
        dateHeader.setText("Date");
        dateHeader.setPadding(5, 5, 5, 5);
        headerRow.addView(dateHeader);
        TextView editHeader = new TextView(this);
        editHeader.setText("Edit");
        editHeader.setPadding(5, 5, 5, 5);
        headerRow.addView(editHeader);
        TextView deleteHeader = new TextView(this);
        deleteHeader.setText("Delete");
        deleteHeader.setPadding(5, 5, 5, 5);
        headerRow.addView(deleteHeader);
        tableLayout.addView(headerRow);

        // Get the weight entries from the database
        WeightDatabase dbHelper = new WeightDatabase(this);
        List<WeightEntry> weightEntries = (List<WeightEntry>) dbHelper.getAllWeights();
        // Loop through the weight entries and add a row for each one
        for (WeightEntry entry : weightEntries) {
            TableRow row = new TableRow(this);
            TextView weightView = new TextView(this);
            weightView.setText(String.valueOf(entry.getWeight()));
            weightView.setPadding(5, 5, 5, 5);
            row.addView(weightView);
            TextView dateView = new TextView(this);
            dateView.setText(entry.getDate());
            dateView.setPadding(5, 5, 5, 5);
            row.addView(dateView);
            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle edit button click
                }
            });
            row.addView(editButton);
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
            row.addView(deleteButton);
            tableLayout.addView(row);
        }
    }



}