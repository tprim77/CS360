package com.zybooks.weighttracking_tylerprimas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class AddWeight extends AppCompatActivity {

    private EditText editTextWeight, editTextDate;
    private Button buttonAdd;

    private WeightDatabase weightDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        editTextWeight = findViewById(R.id.editTextNumberDecimal);
        editTextDate = findViewById(R.id.editTextDate);
        buttonAdd = findViewById(R.id.addButton);

        weightDatabase = new WeightDatabase(this);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double weight = Double.parseDouble(editTextWeight.getText().toString());
                String date = editTextDate.getText().toString();

                boolean success = weightDatabase.addWeight(weight, date);

                if (success) {
                    Toast.makeText(AddWeight.this, "Weight added to database", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AddWeight.this, "Error adding weight to database", Toast.LENGTH_SHORT).show();
                }

                finish();
            }
        });
    }
}
