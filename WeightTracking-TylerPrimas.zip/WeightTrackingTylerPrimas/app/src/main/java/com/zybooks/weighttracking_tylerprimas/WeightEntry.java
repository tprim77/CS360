package com.zybooks.weighttracking_tylerprimas;

public class WeightEntry {
    private long id;
    private double weight;
    private String date;

    public WeightEntry(long id, double weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
