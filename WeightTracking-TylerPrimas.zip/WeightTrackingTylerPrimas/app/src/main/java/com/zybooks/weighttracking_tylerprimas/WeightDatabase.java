package com.zybooks.weighttracking_tylerprimas;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class WeightDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightDatabase.db";
    private static final int DATABASE_VERSION = 1;

    private static final String WEIGHT_TABLE_NAME = "weights";
    private static final String WEIGHT_COLUMN_ID = "_id";
    private static final String WEIGHT_COLUMN_WEIGHT = "weight";
    private static final String WEIGHT_COLUMN_DATE = "date";

    public WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + WEIGHT_TABLE_NAME + " (" +
                WEIGHT_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                WEIGHT_COLUMN_WEIGHT + " REAL NOT NULL, " +
                WEIGHT_COLUMN_DATE + " TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + WEIGHT_TABLE_NAME);
        onCreate(db);
    }

    public boolean addWeight(double weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WEIGHT_COLUMN_WEIGHT, weight);
        values.put(WEIGHT_COLUMN_DATE, date);

        long result = db.insert(WEIGHT_TABLE_NAME, null, values);

        db.close();

        return result != -1;
    }

    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                WEIGHT_COLUMN_ID,
                WEIGHT_COLUMN_WEIGHT,
                WEIGHT_COLUMN_DATE
        };

        Cursor cursor = db.query(
                WEIGHT_TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        return cursor;
    }
}
